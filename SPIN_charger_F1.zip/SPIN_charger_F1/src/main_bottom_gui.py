import webbrowser
from datetime import *

from PyQt5 import QtCore, QtGui, QtWidgets

from config import *

var1 = None

import sys

class TestThread(QtCore.QThread):
    def __init__(self, subject):
        QtCore.QThread.__init__(self)
        self.subject = subject

    def __del__(self):
        self.wait()

    def run(self):
        pass


class Ui_mainboardbottom(object):
    global data_value

    def setupUi(self, mainboardbottom):

        self.get_thread = TestThread(self)
        # QtCore.QObject.connect(self.get_thread, QtCore.SIGNAL("Tempvalueprompt(QString)"), self.value)
        mainboardbottom.setObjectName("mainboardbottom")
        mainboardbottom.resize(1352, 655)
        self.groupBox_1 = QtWidgets.QGroupBox(mainboardbottom)
        self.groupBox_1.setGeometry(QtCore.QRect(20, 90, 261, 221))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.groupBox_1.setFont(font)
        self.groupBox_1.setObjectName("groupBox_1")
        self.barcode_label = QtWidgets.QLabel(self.groupBox_1)
        self.barcode_label.setGeometry(QtCore.QRect(10, 20, 71, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.barcode_label.setFont(font)
        self.barcode_label.setObjectName("barcode_label")
        self.barcode_edit = QtWidgets.QLineEdit(self.groupBox_1)
        self.barcode_edit.setGeometry(QtCore.QRect(100, 20, 141, 21))
        self.barcode_edit.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.barcode_edit.setClearButtonEnabled(False)
        self.barcode_edit.setObjectName("barcode_edit")
        self.part_label = QtWidgets.QLabel(self.groupBox_1)
        self.part_label.setGeometry(QtCore.QRect(8, 50, 91, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.part_label.setFont(font)
        self.part_label.setObjectName("part_label")
        self.part_edit = QtWidgets.QLineEdit(self.groupBox_1)
        self.part_edit.setGeometry(QtCore.QRect(100, 50, 141, 21))
        self.part_edit.setReadOnly(True)
        self.part_edit.setObjectName("part_edit")
        self.name_edit = QtWidgets.QLineEdit(self.groupBox_1)
        self.name_edit.setGeometry(QtCore.QRect(100, 110, 141, 21))
        self.name_edit.setObjectName("name_edit")
        self.serail_label = QtWidgets.QLabel(self.groupBox_1)
        self.serail_label.setGeometry(QtCore.QRect(8, 80, 71, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.serail_label.setFont(font)
        self.serail_label.setObjectName("serail_label")
        self.name_label = QtWidgets.QLabel(self.groupBox_1)
        self.name_label.setGeometry(QtCore.QRect(6, 110, 91, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.name_label.setFont(font)
        self.name_label.setObjectName("name_label")
        self.serial_edit = QtWidgets.QLineEdit(self.groupBox_1)
        self.serial_edit.setGeometry(QtCore.QRect(100, 80, 141, 21))
        self.serial_edit.setReadOnly(True)
        self.serial_edit.setObjectName("serial_edit")
        self.end_label = QtWidgets.QLabel(self.groupBox_1)
        self.end_label.setGeometry(QtCore.QRect(6, 180, 91, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.end_label.setFont(font)
        self.end_label.setObjectName("end_label")
        self.start_label = QtWidgets.QLabel(self.groupBox_1)
        self.start_label.setGeometry(QtCore.QRect(8, 150, 71, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.start_label.setFont(font)
        self.start_label.setObjectName("start_label")
        self.end_edit = QtWidgets.QLineEdit(self.groupBox_1)
        self.end_edit.setGeometry(QtCore.QRect(100, 180, 141, 21))
        self.end_edit.setReadOnly(True)
        self.end_edit.setObjectName("end_edit")
        self.start_edit = QtWidgets.QLineEdit(self.groupBox_1)
        self.start_edit.setGeometry(QtCore.QRect(100, 150, 141, 21))
        self.start_edit.setReadOnly(True)
        self.start_edit.setObjectName("start_edit")
        self.exicomlogo = QtWidgets.QLabel(mainboardbottom)
        self.exicomlogo.setGeometry(QtCore.QRect(60, 20, 161, 51))
        self.exicomlogo.setText("")
        self.exicomlogo.setPixmap(QtGui.QPixmap("../images/logo.png"))
        self.exicomlogo.setScaledContents(True)
        self.exicomlogo.setObjectName("exicomlogo")
        self.log_center = QtWidgets.QTextBrowser(mainboardbottom)
        self.log_center.setGeometry(QtCore.QRect(1020, 90, 295, 401))
        self.log_center.setObjectName("log_center")
        self.display_label = QtWidgets.QLabel(mainboardbottom)
        self.display_label.setGeometry(QtCore.QRect(1020, 50, 81, 21))
        font = QtGui.QFont()
        font.setFamily("Bookman Old Style")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.display_label.setFont(font)
        self.display_label.setObjectName("display_label")
        self.clear_log_pb = QtWidgets.QPushButton(mainboardbottom)
        self.clear_log_pb.setGeometry(QtCore.QRect(1230, 50, 75, 23))
        self.clear_log_pb.setObjectName("clear_log_pb")
        self.clear_log_pb.clicked.connect(self.log_center.clear)
        self.test_label = QtWidgets.QLabel(mainboardbottom)
        self.test_label.setGeometry(QtCore.QRect(490, 40, 311, 41))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.test_label.setFont(font)
        self.test_label.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.test_label.setStyleSheet("color: rgb(0, 85, 255);")
        self.test_label.setAlignment(QtCore.Qt.AlignCenter)
        self.test_label.setWordWrap(True)
        self.test_label.setObjectName("test_label")
        self.status_label = QtWidgets.QLabel(mainboardbottom)
        self.status_label.setGeometry(QtCore.QRect(480, 560, 351, 61))
        font = QtGui.QFont()
        font.setFamily("MV Boli")
        font.setPointSize(20)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.status_label.setFont(font)
        self.status_label.setStyleSheet("font: 20pt \"MV Boli\";")
        self.status_label.setAlignment(QtCore.Qt.AlignCenter)
        self.status_label.setObjectName("status_label")

        self.title_label = QtWidgets.QLabel(mainboardbottom)
        self.title_label.setGeometry(QtCore.QRect(1134, 622, 351, 61))
        font = QtGui.QFont()
        font.setFamily("MV Boli")
        font.setPointSize(20)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.title_label.setFont(font)
        self.title_label.setStyleSheet("font: 12pt \"MV Boli\";")
        self.title_label.setAlignment(QtCore.Qt.AlignCenter)
        self.title_label.setObjectName("status_label")


        self.start_pb = QtWidgets.QPushButton(mainboardbottom)
        self.start_pb.setGeometry(QtCore.QRect(60, 340, 171, 61))
        self.start_pb.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.start_pb.setObjectName("start_pb")
        self.start_pb.clicked.connect(self.start_func)
        self.start_pb.setAutoDefault(True)
        self.stop_pb = QtWidgets.QPushButton(mainboardbottom)
        self.stop_pb.setGeometry(QtCore.QRect(60, 420, 171, 61))
        self.stop_pb.setFocusPolicy(QtCore.Qt.NoFocus)
        self.stop_pb.setObjectName("stop_pb")
        self.stop_pb.clicked.connect(self.stop_func)
        self.horizontalLayoutWidget = QtWidgets.QWidget(mainboardbottom)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(319, 130, 661, 51))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.health_check_label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.health_check_label.setFont(font)
        self.health_check_label.setObjectName("health_check_label")
        self.horizontalLayout.addWidget(self.health_check_label)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.health_status = QtWidgets.QLabel(self.horizontalLayoutWidget)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.health_status.setFont(font)
        self.health_status.setObjectName("health_status")
        self.horizontalLayout.addWidget(self.health_status)
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(mainboardbottom)
        self.horizontalLayoutWidget_2.setGeometry(QtCore.QRect(320, 210, 661, 51))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.power_check_label = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.power_check_label.setFont(font)
        self.power_check_label.setObjectName("power_check_label")
        self.horizontalLayout_2.addWidget(self.power_check_label)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.power_status = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.power_status.setFont(font)
        self.power_status.setObjectName("power_status")
        self.horizontalLayout_2.addWidget(self.power_status)
        self.horizontalLayoutWidget_3 = QtWidgets.QWidget(mainboardbottom)
        self.horizontalLayoutWidget_3.setGeometry(QtCore.QRect(320, 290, 661, 51))
        self.horizontalLayoutWidget_3.setObjectName("horizontalLayoutWidget_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_3)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.comm_check_label = QtWidgets.QLabel(self.horizontalLayoutWidget_3)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.comm_check_label.setFont(font)
        self.comm_check_label.setObjectName("comm_check_label")
        self.horizontalLayout_3.addWidget(self.comm_check_label)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem2)
        self.comm_status = QtWidgets.QLabel(self.horizontalLayoutWidget_3)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.comm_status.setFont(font)
        self.comm_status.setObjectName("comm_status")
        self.horizontalLayout_3.addWidget(self.comm_status)
        self.horizontalLayoutWidget_4 = QtWidgets.QWidget(mainboardbottom)
        self.horizontalLayoutWidget_4.setGeometry(QtCore.QRect(320, 370, 661, 51))
        self.horizontalLayoutWidget_4.setObjectName("horizontalLayoutWidget_4")
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_4)
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.charging_label = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.charging_label.setFont(font)
        self.charging_label.setObjectName("charging_label")
        self.horizontalLayout_4.addWidget(self.charging_label)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem3)
        self.charging_status = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.charging_status.setFont(font)
        self.charging_status.setObjectName("charging_status")
        self.horizontalLayout_4.addWidget(self.charging_status)
        self.help_button = QtWidgets.QPushButton(mainboardbottom)
        self.help_button.setGeometry(QtCore.QRect(1235, 500, 80, 30))
        self.help_button.setObjectName("HELP")
        self.help_button.clicked.connect(self.pdf)
        self.help_button.setAutoDefault(True)
        # self.help_button.hide()  # added for F1, suc
        self.retranslateUi(mainboardbottom)
        QtCore.QMetaObject.connectSlotsByName(mainboardbottom)
        mainboardbottom.setTabOrder(self.name_edit, self.barcode_edit)
        mainboardbottom.setTabOrder(self.barcode_edit, self.start_pb)
        mainboardbottom.setTabOrder(self.start_pb, self.part_edit)
        mainboardbottom.setTabOrder(self.part_edit, self.serial_edit)
        mainboardbottom.setTabOrder(self.serial_edit, self.start_edit)
        mainboardbottom.setTabOrder(self.start_edit, self.end_edit)
        mainboardbottom.setTabOrder(self.end_edit, self.clear_log_pb)
        mainboardbottom.setTabOrder(self.clear_log_pb, self.log_center)
        self.prompt_response = True

    def retranslateUi(self, mainboardbottom):
        _translate = QtCore.QCoreApplication.translate
        mainboardbottom.setWindowTitle(_translate("mainboardbottom", "Main Board Bottom"))
        self.groupBox_1.setTitle(_translate("mainboardbottom", "Test Details"))
        self.barcode_label.setText(_translate("mainboardbottom", "Barcode"))
        self.barcode_edit.setPlaceholderText(_translate("mainboardbottom", "Enter DUT Barcode here"))
        self.part_label.setText(_translate("mainboardbottom", "Part No."))
        self.name_edit.setPlaceholderText(_translate("mainboardbottom", "Enter your name here"))
        self.serail_label.setText(_translate("mainboardbottom", "Serial No."))
        self.name_label.setText(_translate("mainboardbottom", "Operator Name"))
        self.end_label.setText(_translate("mainboardbottom", "End Time"))
        self.start_label.setText(_translate("mainboardbottom", "Start Time"))
        self.display_label.setText(_translate("mainboardbottom", "Test Logs"))
        self.clear_log_pb.setText(_translate("mainboardbottom", "Clear Logs"))
        self.test_label.setText(_translate("mainboardbottom", "Main Board Bottom ATE"))
        self.status_label.setText(_translate("mainboardbottom", "Test in Progress..."))
        self.start_pb.setText(_translate("mainboardbottom", "START"))
        self.stop_pb.setText(_translate("mainboardbottom", "STOP"))
        self.health_check_label.setText(_translate("mainboardbottom", "1. Physial Health Check"))
        self.health_status.setText(_translate("mainboardbottom", "pending..."))
        self.power_check_label.setText(_translate("mainboardbottom", "2. Power Supply Check"))
        self.power_status.setText(_translate("mainboardbottom", "pending..."))
        self.comm_check_label.setText(_translate("mainboardbottom", "3. Communication Check"))
        self.comm_status.setText(_translate("mainboardbottom", "pending..."))
        self.charging_label.setText(_translate("mainboardbottom", "4. Charging Enable Test"))
        self.charging_status.setText(_translate("mainboardbottom", "pending..."))
        self.help_button.setText(_translate('mainboardbottom','HELP!'))
        self.title_label.setText(_translate('mainboardbottom','By : Paras'))

    def start_func(self):
        global var1
        # BARCODE ENTRY CHECK

        if self.barcode_edit.text() is None:
            self.Message("Please enter/scan Barcode first to begin, Testing!")

        elif self.barcode_edit.text() is not None:

            # CHECKING NAME ENTERED

            if len(str(self.name_edit.text())) <= 3:
                self.Message("Kindly enter full name!")
            else:

                # CHECKING BARCODE LENGTH
                if self.barcode_edit.text() == "":
                    self.Message("Kindly enter barcode here!")

                elif len(str(self.barcode_edit.text())) < 24:
                    print(len(str(self.barcode_edit.text())))
                    self.Message("Scanned Barcode is wrong/incorrect!")

                # SPLITTING BARCODE INTO PART CODE AND SERIAL NUMBER

                elif len(str(self.barcode_edit.text())) == 24:
                    part = self.barcode_edit.text().upper().split('#')
                    self.part_edit.setText(part[0].upper())
                    self.serial_edit.setText(part[1].upper())

                    # CHECKING CORRECT LENGTH OF PART CODE AND SERIAL NUMBER
                    if len(str(self.serial_edit.text())) < 15:
                        self.Message("Scanned Barcode is incorrect")
                    else:
                        retry_flag = True
                        file_path = "..\\logs\\bottom_console\\log_" + str(self.barcode_edit.text()).upper() + "_" + str(self.name_edit.text()).upper() + "_" + str(self.GETTIME()) + '.txt'
                        sys.stdout = open(file_path, "w")
                        while retry_flag:
                            self.Message("Click OK to begin!")
                            date_time = self.get_date_time()
                            self.start_edit.setText(date_time)
                            self.log_center.clear()
                            self.health_status.setText("pending...")
                            self.health_status.setStyleSheet("")
                            self.power_status.setText("pending...")
                            self.power_status.setStyleSheet("")
                            self.comm_status.setText("pending...")
                            self.comm_status.setStyleSheet("")
                            self.charging_status.setText("pending...")
                            self.charging_status.setStyleSheet("")
                            self.phys_testing_flag = True
                            self.power_testing_flag = True
                            self.comm_testing_flag = True
                            self.charging_testing_flag = True
                            self.Result_Status = []
                            self.console("Start time is : " + date_time)
                            while self.phys_testing_flag:
                                self.status_label.setText('Under testing...')
                                self.health_status.setStyleSheet("color:BLACK")
                                self.health_status.setText('testing...')
                                print("proceed!")
                                Result = self.Physical_test()
                                result = True
                                for i in Result:
                                    if i == False:
                                        result = False

                                if result == True:
                                    self.health_status.setText("Pass")
                                    self.health_status.setStyleSheet("color:GREEN")
                                    self.console("Physical Test Pass!", "GREEN")
                                    self.phys_testing_flag = False
                                else:
                                    self.health_status.setText("Fail")
                                    self.health_status.setStyleSheet("color:RED")
                                    self.console("Physical Test Fail!", "RED")
                                    response = self.User_prompt("Do you want to retry?")
                                    if response == True:
                                        self.phy_testing_flag = True
                                    else:
                                        self.phys_testing_flag = False
                            self.Result_Status.append(result)
                            for i in self.Result_Status:
                                if i == False:
                                    user_response = self.User_prompt("Do you want to continue?")
                                    if user_response == True:
                                        break
                                    else:
                                        retry_flag = False
                                        print("failed")
                                        self.power_testing_flag=False
                                        self.comm_testing_flag=False
                                        self.charging_testing_flag=False
                            while self.power_testing_flag:
                                self.status_label.setText('Under testing...')
                                self.power_status.setStyleSheet("color:BLACK")
                                self.power_status.setText('testing...')
                                print("proceed!")
                                Result = self.Power_Supply_Test()
                                result = True
                                for i in Result:
                                    if i == False:
                                        result = False

                                if result == True:
                                    self.power_status.setText("Pass")
                                    self.power_status.setStyleSheet("color:GREEN")
                                    self.console("Power Supply Test Pass!", "GREEN")
                                    self.power_testing_flag = False
                                else:
                                    self.power_status.setText("Fail")
                                    self.power_status.setStyleSheet("color:RED")
                                    self.console("Power Supply Test Fail!", "RED")
                                    response = self.User_prompt("Do you want to retry?")
                                    if response == True:
                                        self.power_testing_flag = True
                                    else:
                                        self.power_testing_flag = False
                            self.Result_Status.append(result)
                            for i in self.Result_Status:
                                if i == False:
                                    if retry_flag==True:
                                        user_response = self.User_prompt("Do you want to continue?")
                                        if user_response == True:
                                            break
                                        else:
                                            retry_flag = False
                                            self.comm_testing_flag=False
                                            self.charging_testing_flag=False
                            while self.comm_testing_flag:
                                self.status_label.setText('Under testing...')
                                self.comm_status.setStyleSheet("color:BLACK")
                                self.comm_status.setText('testing...')
                                print("proceed!")
                                Result = self.Comm_test()
                                result = True
                                for i in Result:
                                    if i == False:
                                        result = False

                                if result == True:
                                    self.comm_status.setText("Pass")
                                    self.comm_status.setStyleSheet("color:GREEN")
                                    self.console("Communication Test Pass!", "GREEN")
                                    self.comm_testing_flag = False
                                else:
                                    self.comm_status.setText("Fail")
                                    self.comm_status.setStyleSheet("color:RED")
                                    self.console("Communication Test Fail!", "RED")
                                    response = self.User_prompt("Do you want to retry?")
                                    if response == True:
                                        self.comm_testing_flag = True
                                    else:
                                        self.comm_testing_flag = False
                            self.Result_Status.append(result)
                            for i in self.Result_Status:
                                if i == False:
                                    if retry_flag==True:
                                        user_response = self.User_prompt("Do you want to continue?")
                                        if user_response == True:
                                            break
                                        else:
                                            retry_flag = False
                                            self.charging_testing_flag=False
                            while self.charging_testing_flag:
                                self.status_label.setText('Under testing...')
                                self.charging_status.setStyleSheet("color:BLACK")
                                self.charging_status.setText('testing...')
                                print("proceed!")
                                Result = self.Charging_test()
                                result = True
                                for i in Result:
                                    if i == False:
                                        result = False

                                if result == True:
                                    self.charging_status.setText("Pass")
                                    self.charging_status.setStyleSheet("color:GREEN")
                                    self.console("Charging Test Pass!", "GREEN")
                                    self.charging_testing_flag = False
                                else:
                                    self.charging_status.setText("Fail")
                                    self.charging_status.setStyleSheet("color:RED")
                                    self.console("Charging Test Fail!", "RED")
                                    response = self.User_prompt("Do you want to retry?")
                                    if response == True:
                                        self.charging_testing_flag = True
                                    else:
                                        self.charging_testing_flag = False
                            self.Result_Status.append(result)
                            final_result = True
                            for i in self.Result_Status:
                                if i == False:
                                    final_result = False
                                    retry_flag = False
                            if final_result == True:
                                self.status_label.setText("Passed")
                                self.status_label.setStyleSheet("color:GREEN")
                                # self.barcode_edit.clear()
                            else:
                                self.status_label.setText("Failed")
                                self.status_label.setStyleSheet("color:RED")
                            retry_flag = False
                            sys.stdout.close()

                    self.console("End Time is : " + self.get_date_time())
                    self.end_edit.setText(self.get_date_time())
                    self.log()
                    self.testing_flag = False

    def stop_func(self):
        if self.status_label.text() == "Test Halted!...":
            self.Message("Test is already stopped!")
        else:
            self.status_label.setText("Test Halted!...")
            self.status_label.setStyleSheet("color:RED")
            self.part_edit.clear()
            self.serial_edit.clear()
            self.start_edit.clear()
            self.health_status.setText("pending...")
            self.health_status.setStyleSheet("")
            self.power_status.setText("pending...")
            self.power_status.setStyleSheet("")
            self.comm_status.setText("pending...")
            self.comm_status.setStyleSheet("")
            self.charging_status.setText("pending...")
            self.charging_status.setStyleSheet("")
            date_time = self.get_date_time()
            self.end_edit.setText(date_time)

    def console(self,prompt,color=""):
        self.log_center.append(prompt)
        self.log_center.setStyleSheet("color:"+color)
        self.log_center.setStyleSheet("")

    def Physical_test(self):
        result = []
        print("starting physical test...")
        self.console("Physical Verification Test started...","BLUE")
        result_temp = False
        user_response = self.User_prompt("Is everything fine?")
        if user_response == True:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = self.User_prompt("Check whether R35, R3, R12 is mounted?")
        if user_response == False:
            result_temp = True
            self.console("Everything looks OK!","Blue")
        else:
            result_temp = False
            self.console("Everything looks not OK!","Red")
        result.append(result_temp)
        print(result)
        return result

    def Power_Supply_Test(self):
        result = []
        result_temp = False
        print("Power Supply Test started...")
        self.console("Power Supply Test Started...")
        user_response = self.User_prompt("Is Supply connection firmly connected to Device Under Testing?")
        if user_response == True:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        self.Message("Short the pins of connector X2 and X3 using Jumpers!")
        user_response = self.User_prompt("Is X2 and X3 connectors are short via Jumpers?")
        if user_response == True:
            self.console("X2 and X3 connectors are plugged!")
            result_temp = True
        else:
            self.console("required connector not plugged!")
            result_temp = False
        result.append(result_temp)
        user_response = self.User_prompt("Switch ON 230VAC Supply!")
        if user_response == True:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = self.User_prompt("Are LED D11 and LD8, SOLID ON?")
        if user_response == True:
            self.console("LED D11 and D8 ON")
            result_temp = True
        else:
            self.console("LED D11 or D8 not glowing")
            result_temp = False
        result.append(result_temp)
        self.Message("Connect X1 connector of Main Bottom Card to X1 connector on Bottom PCA using 12-pin connector!")
        # time.sleep(1)
        self.Message("Short J1 connector on Bottom PCA Testing setup using a Jumper!")
        user_response = self.User_prompt("Is LS1 Relay ON?")
        if user_response == True:
            self.console("LS1 relay OK")
            result_temp = True
        else:
            self.console("LS1 relay not OK")
            result_temp = False
        result.append(result_temp)
        user_response= float(self.user_value("Phase_IN and Neutral_IN"))
        print(user_response)
        if user_response <= float(Setting_Read("BOTTOM")["pin_nin_high"]) and user_response >= float(Setting_Read("BOTTOM")['pin_nin_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("Phase_OUT and Neutral_IN"))
        if user_response <= float(Setting_Read("BOTTOM")["pout_nin_high"]) and user_response >= float(
                Setting_Read("BOTTOM")['pout_nin_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("Neutral_IN and Earth_IN"))
        if user_response <= float(Setting_Read("BOTTOM")["nin_e_high"]) and user_response >= float(
                Setting_Read("BOTTOM")['nin_e_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("15v-GND"))
        if user_response <= float(Setting_Read("BOTTOM")["15v_gnd_high"]) and user_response >= float(Setting_Read("BOTTOM")['15v_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("5V-GND"))
        if user_response <= float(Setting_Read("BOTTOM")['5v_gnd_high']) and user_response >= float(Setting_Read("BOTTOM")['5v_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("3.3V-GND"))
        if user_response <= float(Setting_Read("BOTTOM")['3v3_gnd_high']) and user_response >= float(Setting_Read("BOTTOM")['3v3_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("1.25V-GND"))
        if user_response <= float(Setting_Read("BOTTOM")['1v25_gnd_high']) and user_response >= float(Setting_Read("BOTTOM")['1v25_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("2.5V-GND"))
        if float(Setting_Read("BOTTOM")['2v5_gnd_high']) >= user_response >= float(Setting_Read("BOTTOM")['2v5_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("C26-GND_DC"))
        if user_response <= float(Setting_Read("BOTTOM")['c26_high_dc']) and user_response >= float(Setting_Read("BOTTOM")['c26_low_dc']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("C26-GND_AC"))
        if user_response <= float(Setting_Read("BOTTOM")['c26_high_ac']) and user_response >= float(
                Setting_Read("BOTTOM")['c26_low_ac']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("VPN-GND_DC"))
        if user_response <= float(Setting_Read("BOTTOM")['vpn_gnd_high']) and user_response >= float(Setting_Read("BOTTOM")['vpn_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("VPN-GND_AC"))
        if user_response <= float(Setting_Read("BOTTOM")['vpn_high']) and user_response >= float(
                Setting_Read("BOTTOM")['vpn_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("VNE-GND_DC"))
        if user_response <= float(Setting_Read("BOTTOM")['vne_gnd_high']) and user_response >= float(Setting_Read("BOTTOM")['vne_gnd_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value("VNE-GND_AC"))
        if user_response <= float(Setting_Read("BOTTOM")['vne_high']) and user_response >= float(
                Setting_Read("BOTTOM")['vne_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        return result

    def Comm_test(self):
        result = []
        print("starting communication test...")
        self.console("Communication Test started...", "BLUE")
        result_temp = False
        user_response = self.User_prompt("Restart Power Supply.")
        if user_response == True:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        self.Message("Disconnect Bottom PCA Testing Setup and Connect BOTTOM PCA to Top PCA using 12 wire jumper")
        user_response = self.User_prompt("Is Connector connected between BOTTOM and TOP PCA?")
        if user_response == True:
            result_temp = True
            self.console("Connector connected between BOTTOM & TOP PCA", "Blue")
        else:
            result_temp = False
            self.console("Connector not connected!", "Red")
        result.append(result_temp)
        self.Message("Connect Bluetooth to J1")
        user_response = self.User_prompt("Is Bluetooth connected and powered up?")
        if user_response == True:
            result_temp = True
            self.console("Bluetooth connected!", "Blue")
        else:
            result_temp = False
            self.console("Bluetooth not connected!", "Red")
        result.append(result_temp)
        self.Message("Connect MOV Card with 2 wire Jumper to X3 connector!")
        self.Message("Connect Simulator PCA to X4 Connector!")
        user_response = self.User_prompt("Is J9 connected to Simulator PCA")
        if user_response == False:
            result_temp = True
            self.console("J9 not connected", "Blue")
        else:
            result_temp = False
            self.console("J9 connected", "Red")
        result.append(result_temp)
        self.Message("Connect Load connections")
        user_response = self.User_prompt("Is Load Connectors plugged?")
        if user_response == True:
            result_temp = True
            self.console("Load connection OK", "Blue")
        else:
            result_temp = False
            self.console("Load connection not OK", "Red")
        result.append(result_temp)
        self.Message("Now connect Bluetooth to EV Debug APP and go to Live Parameters")
        user_response = self.User_prompt("Are you able to see data on the APP?")
        if user_response == True:
            result_temp = True
            self.console("Bluetooth communication OK", "Blue")
        else:
            result_temp = False
            self.console("Bluetooth Communication Fail", "Red")
        result.append(result_temp)
        user_response = float(self.user_value_2("Voltage from APP","V"))
        if user_response <= float(Setting_Read("BOTTOM")['pin_nin_high']) and user_response >= float(
                Setting_Read("BOTTOM")['pin_nin_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value_2("Current from APP","A"))
        if user_response <= 0.3 and user_response >= 0.0:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value_2("NE Voltage from APP","V"))
        if user_response <= float(Setting_Read("BOTTOM")['nin_e_high']) and user_response >= float(
                Setting_Read("BOTTOM")['nin_e_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value_2("Earth Leakage Current from APP","mA"))
        if user_response <= 5.0 and user_response >= 0.0:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value_2("Temperature from APP",'\u00B0'+"C"))
        if user_response <= float(Setting_Read("BOTTOM")['temp_high']) and user_response >= float(
                Setting_Read("BOTTOM")['temp_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        return result

    def Charging_test(self):
        result = []
        print("starting charging test...")
        self.console("Charging test started...", "BLUE")
        result_temp = False
        self.Message("Connect J9 Jumper on Simulator PCA")
        user_response = self.User_prompt("Is J9 connected?")
        if user_response == True:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        self.Message("Connect to Bluetooth via Debug APP")
        user_response = self.User_prompt("Is Charger status under Live Parameters in APP : Charging?")
        if user_response == True:
            result_temp = True
            self.console("Charging status OK", "Blue")
        else:
            result_temp = False
            self.console("Charging status Fail!", "Red")
        result.append(result_temp)
        user_response = float(self.user_value_2("Voltage from APP","V"))
        if user_response <= float(Setting_Read("BOTTOM")['pin_nin_high']) and user_response >= float(
                Setting_Read("BOTTOM")['pin_nin_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        self.Message("Now START Auto_Load_ATS and give 15A Load")
        user_response = float(self.user_value_2("Current Measure from APP","A"))
        if user_response <= float(Setting_Read("BOTTOM")['load_high']) and user_response >= float(
                Setting_Read("BOTTOM")['load_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        self.Message("Turn off the Load!")
        user_response = float(self.user_value_2("NE Voltage from APP","V"))
        if user_response <= float(Setting_Read("BOTTOM")['nin_e_high']) and user_response >= float(
                Setting_Read("BOTTOM")['nin_e_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value_2("Earth Leakage Current from APP","mA"))
        if user_response <= 5.0 and user_response >= 0.0:
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        user_response = float(self.user_value_2("Temperature from APP",'\u00B0'+"C"))
        if user_response <= float(Setting_Read("BOTTOM")['temp_high']) and user_response >= float(
                Setting_Read("BOTTOM")['temp_low']):
            result_temp = True
        else:
            result_temp = False
        result.append(result_temp)
        return result

    def GETTIME(self):
        time_var = datetime.now()
        time_var = str(time_var.date())+"_"+str(time_var.time().hour)+"_"+str(time_var.time().minute)
        return time_var

    def log(self):

        '''Log Creation'''

        filename = "..\\logs\\bottom\log_" + str(
            self.barcode_edit.text()).upper() + "_" + self.status_label.text() + "_" + str(
            self.name_edit.text()).upper() + "_" + str(self.GETTIME()) + '.txt'
        myfile = open(filename, 'w')
        myfile.write("DUT PART NUMBER: " + self.part_edit.text())
        myfile.write('\n\n')
        myfile.write("DUT SERIAL NUMBER: " + self.serial_edit.text())
        myfile.write('\n\n')
        myfile.write("Testing Engg. Name: " + self.name_edit.text().upper())
        myfile.write('\n\n')
        myfile.write(self.log_center.toPlainText())
        myfile.write('\n\n')
        myfile.close()
        self.barcode_edit.clear()
        self.part_edit.clear()
        self.part_edit.setStyleSheet("")
        self.serial_edit.clear()
        self.serial_edit.setStyleSheet("")

    def user_value(self, parameter_to_measure):
        value = True
        test = None
        while value:
            test, ok = QtWidgets.QInputDialog.getText(None, "Enter Voltage","Enter measured Voltage between : " + parameter_to_measure)
            print(test)
            if test == "":
                self.Message("Can't proceed with Blank...\n\nKindly enter value to proceed!")
                value = True
            else:
                if parameter_to_measure == "VPN-GND_AC" or parameter_to_measure == "C26-GND_AC" or parameter_to_measure == 'VNE-GND_AC':
                    self.log_center.append("Voltage value across " + parameter_to_measure + " : " + str(test) + " mV")
                else:
                    self.log_center.append("Voltage value across " + parameter_to_measure + " : " + str(test) + " V")
                value = False
        return test

    def user_value_2(self, parameter_to_measure,unit):
        value = True
        test = None
        while value:
            test, ok = QtWidgets.QInputDialog.getText(None, "Enter parameter", parameter_to_measure)
            print(test)
            if test == "":
                self.Message("Can't proceed with Blank...\n\nKindly enter value to proceed!")
                value = True
            else:
                self.log_center.append(parameter_to_measure + " : " + str(test) + " " + unit)
                value = False
        return test

    def Message(self, message):
        self.message = QtWidgets.QMessageBox()
        self.message.setWindowTitle('Message!')
        self.message.setWindowIcon(QtGui.QIcon(QtGui.QPixmap("../images/message.png")))
        self.message.setText(message)
        self.message.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok)
        self.message.exec_()

    def User_prompt(self, user_prompt):
        print(user_prompt)
        self.prompt = None
        response = QtWidgets.QMessageBox.question(QtWidgets.QDialog(), "USER PROMPT", user_prompt,
                                                  QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No)
        if response == QtWidgets.QMessageBox.StandardButton.Yes:
            self.prompt = True
        elif response == QtWidgets.QMessageBox.StandardButton.No:
            self.prompt = False
        return self.prompt

    def get_date_time(self):
        now = datetime.now()
        year = str(now.year)
        month = str(now.month)
        if len(month) == 1:
            month = '0' + month
        day = str(now.day)
        if len(day) == 1:
            day = '0' + day
        date = day + "/" + month + "/" + year
        hour = str(now.hour)
        if len(hour) == 1:
            hour = '0' + hour
        minute = str(now.minute)
        if len(minute) == 1:
            minute = '0' + minute
        second = str(now.second)
        if len(second) == 1:
            second = '0' + second
        time = hour + ":" + minute + ":" + second
        date_time_now = date + " " + time
        return date_time_now

    def MessagePrompt(self, prompt_message, timeout='5', title='MESSAGE!'):
        # self.response = None
        messagebox = TimerMessageBox(title, prompt_message, int(timeout))
        messagebox.exec_()
        # self.response = True

    def pdf(self):
        webbrowser.open_new(r'file://D:\SPIN\PTP\BOTTOM_PTP.pdf')

class TimerMessageBox(QtWidgets.QMessageBox):
    def __init__(self, title='MESSAGE!', text='None', timeout=10, parent=None):
        super(TimerMessageBox, self).__init__(parent)
        self.setWindowTitle(title)
        if timeout == 0:
            self.time_to_wait = 90
        else:
            self.time_to_wait = timeout
        self.text_to_set = text
        self.setText(self.text_to_set + " ({0})".format(self.time_to_wait))
        self.setIcon(1)
        # self.setStandardButtons(QtWidgets.QMessageBox.Ok)
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.changeContent)
        self.timer.start()

    def changeContent(self):
        self.setText(self.text_to_set + " ({0})".format(self.time_to_wait))
        self.time_to_wait -= 1
        if self.time_to_wait == 0:
            self.close()

    def closeEvent(self, event):
        self.timer.stop()
        event.accept()


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    mainboardbottom = QtWidgets.QWidget()
    ui = Ui_mainboardbottom()
    ui.setupUi(mainboardbottom)
    mainboardbottom.show()
    sys.exit(app.exec_())

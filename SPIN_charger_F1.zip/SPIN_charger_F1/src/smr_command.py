import time

from can import Message
from can.interfaces.ixxat import IXXATBus, exceptions
global status

def commands_set(can_channel,cont1,cont2):
    try:
        bus = IXXATBus(channel=can_channel, can_filters=[{"can_id":0x00,"can_mask":0x000}],bitrate=250000)

    except exceptions.VCIDeviceNotFoundError:
        bus = None

    try:
        # dc_enable_msg = Message(arbitration_id=0x60a,data=[0,0,0,0,0,0,0,0])
        op_enable_msg = Message(arbitration_id=0x60A,is_extended_id=False,data=[0x2B,0x00,0x20,0x00,cont1,cont2,0,0])

        bus.send(op_enable_msg)

        time.sleep(0.5)

        print(op_enable_msg)

        bus.shutdown()

    except AttributeError:
        print(cont1,cont2)

def stop_command(can_channel):
    try:
        bus = IXXATBus(channel=can_channel, can_filters=[{"can_id":0x00,"can_mask":0x000}],bitrate=250000)

    except exceptions.VCIDeviceNotFoundError:
        bus = None

    try:
        # dc_enable_msg = Message(arbitration_id=0x60a,data=[0,0,0,0,0,0,0,0])

        op_enable_msg = Message(arbitration_id=0x60A,is_extended_id=False,data=[0x2B,0x00,0x20,0x00,0,0,0,0])

        bus.send(op_enable_msg)

        time.sleep(1)

        print(op_enable_msg)

        bus.shutdown()

    except AttributeError:
        print("Attribute Error")

    print("Stoppeddd!!!!")
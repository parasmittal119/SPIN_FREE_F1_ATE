import configparser
global config
config = configparser.ConfigParser()
def Setting_Read(section):
    config.read("..\\files\setting.txt")
    # config.read('setting.txt')
    dict1={}
    options =config.options(section)
    for option in options:
        dict1[option]=config.get(section,option)
    return dict1
